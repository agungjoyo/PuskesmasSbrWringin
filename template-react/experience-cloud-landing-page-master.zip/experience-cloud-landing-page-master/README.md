### experience-cloud

体验云的 landing page. 

脚手架使用的是： [antd-init](https://github.com/ant-design/antd-init);

## preview

https://xcloud.alipay.com/

https://ant-motion.github.io/experience-cloud-landing-page/


## install
```
$ npm i 
```

## Development

```
$ npm start
```